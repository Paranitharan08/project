import React, { Component } from 'react'
import { Card, CardActionArea, Typography } from '@material-ui/core';

const style = {
    content:{
        backgroundColor:"white",
        height:400,
        width:300,
        marginLeft:300,
        marginTop:200,
        borderRadius:30,
        color:"red"
    },

    text:{
        fontSize:"20px",
        fontWeight:"bold",
        padding:10,
        textAlign:"center"
    }

}

export default class ServiceProviderHome extends Component{
    constructor(){
        super();
    }

    render(){
        return(
            <div>
                <Card style={{backgroundColor:"black",height:"100vh",width:"100%"}}>
                    <div style={{display:"flex"}}>
                        <Card style={style.content}>

                            <CardActionArea>
                            <Typography style={style.text}>Add Service Provider</Typography>
                            </CardActionArea>

                        </Card>
                        
                        <Card style={style.content}>

                            <CardActionArea>
                            <Typography style={style.text}>View Service Provider</Typography>
                            </CardActionArea>

                        </Card>
                    </div>

                </Card>

            </div>
        );
    }
}