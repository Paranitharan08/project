import React from 'react';
import ReactDOM from 'react-dom';
// import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import VerticalTabs from './Components/Details';
import UserEntry from './Components/isai';
import Home from './Components/new';
import Signup from './Components/signup';
import BuyNow from './Components/test';
import SocialLink from './Components/test';
import TitlebarGridList from './Components/test';
import Login from './Components/Login';
import ServiceHome from './Components/ServiceHome';
import Register from './Components/Register';
import Adminpage from './Components/Admin';
import { ExpansionPanel } from '@material-ui/core';
import BookList from './Components/test';
// import Example from './Components/test'
import ContactUs from './Components/ContactUs'
import FindStation from './Components/findstation';
import Counter from './Components/Endpage';
import Timer from './Components/Endpage';
import Foo from './Components/Feedback';
import Feedback from './Components/Feedback';
import History from './Components/history';
import Reservation from './Components/test';
import UpdateUser from './Components/UpdateUser';
import SproviderHome from './Components/sproviderHome';
import ServiceProviderHome from './Components/sproviderHome';
import ViewsProvider from './Components/viewsprovider';
import AddService from './Components/addservice';
import ImageUpload from './Components/imageupload';


ReactDOM.render(
  <React.StrictMode>
    <ImageUpload/>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
