import React, { Component } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';
import { Button, TableFooter, TablePagination } from '@material-ui/core';
import authservice from '../Services/authservice';
import EditIcon from '@material-ui/icons/Edit';
import PropTypes from 'prop-types';
import { useTheme } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';


const useStyles1 = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};



// const useStyles = {
//   table: {
//     minWidth: 650,
//     height:"auto"
//   },
// };

// function createData(username, Email, mobno) {
//   return { username, Email, mobno };
// }

// const rows = [
//   createData('Paranitharan',"Parani@gmail.com", "0147258369"),
//   createData('Esaiajarasan', "Esai@gmail.com", "1472583690"),
//   createData('Sinthujan', "Sinthu@gmail.com", "2583691470"),
//   createData('Abcd', "abcd@gmail.com", "1234567890"),
//   createData('Abcdef', "Abcdef@gmail.com", "7891234560"),
// ];

// onRowDelete = (oldData
            //   <TableCell style={{ width: 160 }} align="right">
            //   {row.calories}
            // </TableCell>) =>
//           new Promise((resolve) => {
//             setTimeout(() => {
//               resolve();
//               setState((prevState) => {
//                 const data = [...prevState.data];
//                 data.splice(data.indexOf(oldData), 1);
//                 return { ...prevState, data };
//               });
//             }, 600);
//           })
            //   <TableCell style={{ width: 160 }} align="right">
            //   {row.calories}
            // </TableCell>



export default class SimpleTable extends Component {
  constructor(){
    super();
    this.state={
     users:[],
     page:0,
     rowsPerPage:5,
     count:0
    
    }

  }

  componentDidMount(){
    this.getAllUser();
  }

  
  
  // getAllUser = () => {
  //   authservice.getAllUser()
  //   .then((res) => {
  //     let users=res.data;
  //       this.setState({
  //         users:users,
  //       })
  //   })
  // }

  handleChangePage = (event,newPage) => {
    this.setState({
      page:newPage
    });

  authservice.getAllUserInPage(newPage,5)
  .then((response) => {
    console.log(response.data.data);
    this.setState({
      users:response.data.data,
      count:response.data.Totalnoofelements      
    })
    console.log(this.state.users);
  })
  };

  getAllUser = () => {
    authservice.getAllUserInPage(this.state.page,5)
    .then((response) => {
      this.setState ({
        users:response.data.data,
        count:response.data.data.Totalnoofelements
      })
    })
  }
  deleteUser = (UserId)=>{
    authservice.deleteUser(UserId)
    .then(res => {
      this.setState({message:'User deeted successfully,'});
      this.setState({users:this.state.users.filter(users => users!==UserId)});
    });
  }


  handleChangeRowsPerPage = (event) => {
    this.setState({
      page:0,
      rowsPerPage:event.target.value
    })
  };
  
  
render(){
  const users = this.state.users;
  return (
      <Paper>
    <TableContainer style={{backgroundColor:"lightgray",marginTop:80, border:"2px solid black"}}  component={Paper}>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow style={{backgroundColor:"black"}}>
          <TableCell style={{color:"gold"}}></TableCell>
          <TableCell style={{color:"gold"}}></TableCell>
            <TableCell style={{color:"gold"}}><b>User Name</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>Email</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>Mobile number</b></TableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map(row =>(
            
            <TableRow key={row.id}>
              <TableCell onClick={()=>this.deleteUser(row.id)}><Button><DeleteRoundedIcon/></Button></TableCell>
              <TableCell><Button href={"/updateuser/"+row.id} ><EditIcon/></Button></TableCell>
              <TableCell component="th" scope="row">{row.username}</TableCell>
              <TableCell align="right">{row.email}</TableCell>
              <TableCell align="right">{row.mobilenumber}</TableCell>
            </TableRow>
            ))}
          
            
          
        </TableBody>
        <TableFooter>
          <TableRow>
            <TablePagination
              // rowsPerPageOptions={[5, 10, 25, { label: 'All', value: -1 }]}
              // colSpan={3}
              count={this.state.count}
              rowsPerPage={this.state.rowsPerPage}
              page={this.state.page}
              SelectProps={{
                inputProps: { 'aria-label': 'rows per page' },
                native: true,
              }}
              onChangePage={this.handleChangePage}
              onChangeRowsPerPage={this.handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
          </TableRow>
        </TableFooter>
      </Table>
    </TableContainer>
    </Paper>
  );
  }
}
