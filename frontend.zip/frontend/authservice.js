import axios from "axios";

const API_URL = "http://localhost:8080/api/auth/"; 

class AuthService {
    login(username,password) {
        return axios.post(API_URL + "signin",{
              username,
              password
        
         } )
         .then(response => {
             if (response.data.basicToken) {
                 localStorage.setItem("users",JSON.stringify(response.data));
             }
             return response.data;
         });
    }

    logout() {
        localStorage.removeItem("users");
        axios.post(API_URL + "logout", {});
    }

    register(firstname,lastname,mobilenumber,username,email,password,roles) {
        return axios.post(API_URL + "signup",{
            firstname,
            lastname,
            mobilenumber,
            username,
            email,
            password,
            roles
        });
    }
    getUserById(UserId){
        return axios.get("http://localhost:8080/api/test/" + UserId)
    }

    getCurrentUser() {
        return JSON.parse(localStorage.getItem('users'));
    }

    getAllUser(){
        return axios.get("http://localhost:8080/api/test");
    }
    getAllUserInPage(pageNo,pageSize,sortBy){
        return axios.get("http://localhost:8080/api/test/page?pageNo="+pageNo+"&pageSize="+pageSize+"&sortBy="+sortBy)
    }

    updateUser(UserBody){
        return axios.put("http://localhost:8080/api/test/updateuser/" + UserBody.id,UserBody);
    }

    deleteServicestation(UserId){
        console.log(UserId);
        
        return axios.delete("http://localhost:8080/api/test/" + UserId)
    }
}

export default new AuthService();