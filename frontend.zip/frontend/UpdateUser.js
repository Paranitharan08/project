import React, { Component } from 'react';
import { Card, Checkbox, Button, Typography, FormLabel, RadioGroup, FormControlLabel, Radio } from '@material-ui/core';
import { TextValidator } from 'react-material-ui-form-validator';
import ValidatorForm from 'react-form-validator-core/lib/ValidatorForm';
import authservice from '../Services/authservice';

const style = {
    card : {
        padding:20,
        width:400,
        // borderRadius:50,
        // backgroundColor:"red"
    },
    out : {
        padding:50,
        borderStyle:"double",
        borderRadius:25,
        width:800,
        marginLeft:"10%",
        marginTop:"5%",
        backgroundColor:"lightgray"
    }
}

export default class UpdateUser extends Component{
    constructor(){
        super();

        this.state={
            id:"",
            firstname:"",
            lastname:"",
            username:"",
            email:"",
            password:"",
            confirmpassword:"",
            mobilenumber:"",
            roles:""

        }
    }

    componentDidMount() {
        // custom validation to verify username 
        ValidatorForm.addValidationRule('isName', (value) => {
            if ((this.state.username.length) >3 && (this.state.username.length) <30){
                return true; 
            }
            return false;            
        });
  
        // custom validation to verify password
        ValidatorForm.addValidationRule('isPassword', (value) => {
          if ((this.state.password.length) >8 && (this.state.password.length) <20){
              return true; 
          }
          return false;            
        });
  
        // confirm password validation
        ValidatorForm.addValidationRule('isConfirmpw',(value)=> {
          if ((this.state.password) == (this.state.confirmpassword)){
            return true;
          }
          return false;
        });
      }

      handleFirstnameChange= (e) => {
        this.setState({
            firstname: e.target.value
        });
        console.log(this.state.firstname);
      }
  
      handleLastnameChange= (e) => {
        this.setState({
            lastname: e.target.value
        });
        console.log(this.state.lastname);
      }
  
      handleMobilenumberChange= (e) => {
        this.setState({
            mobilenumber: e.target.value
        });
        console.log(this.state.mobilenumber);
      }
  
      
      handleUnameChange= (e) => {
          this.setState({
              username: e.target.value
          });
          console.log(this.state.username);
      }
  
      handleEmailChange = (e) => {
          this.setState({
              email: e.target.value
          });
          console.log(this.state.email);
      }
  //     handlePasswordchange = (e) => {
  //         this.setState({
  //             password: e.target.value
  //         });
  //         console.log(this.state.password);
  //     }
  //     handleconfirmPasswordchange = (e) => {
  //       this.setState({
  //           confirmpassword: e.target.value
  //       });
  //       console.log(this.state.confirmpassword);
  //   }
  //   handleconfirmPasswordchange = (e) => {
  //     this.setState({
  //         confirmpassword: e.target.value
  //     });
  //     console.log(this.state.confirmpassword);
  // }
  //     handleuserchange= (e) => {
  //       this.setState({
  //         roles: e.target.value
  //       });
  //       console.log(this.state.roles); 
  //     }

      componentDidMount(){
        const userId = this.props.match.params.id;
        if(userId){
          this.loadUser(userId);
        }
      }

      loadUser = (userId) => {
        authservice.getUserById(userId)
        .then((res) => {
          let User = res.data;
          this.setState({
            id: User.id,
            firstname: User.firstname,
            lastname: User.lastname,
            username: User.username,
            email: User.email,
            mobilenumber: User.mobilenumber,
          })
        })
      }

      // UpdateUser = (e) => {
      //   e.preventDefault();
        
      // }

      handleSubmit= (e) => {
        e.preventDefault();
        
        if (this.state.username 
          && this.state.email 
          && this.state.password 
          && this.state.roles
          && this.state.firstname
          && this.state.lastname
          && this.state.mobilenumber
          ) {
            console.log(this.state.username + " " + this.state.password + " " + this.state.email)
            this.setState({
              successful: true,
              message: "Registered successfully"
            })
          } else {
            this.setState({
              successful: false,
              message: "please fill all feilds"
            })
          }
          let UserBody = {
            id: this.state.id,
            firstname: this.state.firstname,
            lastname: this.state.lastname,
            username: this.state.username,
            email: this.state.email,
            mobilenumber: this.state.mobilenumber,
          };
          authservice.updateUser(UserBody)
          
          .then(res => {
            this.setState({message:"User updated successfully"});
            
          })
        }

    render(){
        const { firstname, lastname, username, email, password, confirmpassword, mobilenumber, roles} = this.state
        return(
            <div>
                <Card style={style.out}>
                {/* <Card elevation={0}> */}
                  
                  <h2>Update Details</h2>
                  <ValidatorForm
                  ref="form"
                  onSubmit={this.handleSubmit}
                  onError={errors => console.log(errors)}>
                <Card style={{display:"flex",borderRadius:25}} elevation={0}>
                  <Card style={style.card} elevation={0}>

                  <TextValidator
                  label='firstname'
                  onChange={this.handleFirstnameChange}
                  name="username"
                  value={firstname}
                  validators={['required']}
                  errorMessages={['this field is required']} />

                  <br></br>
                  

                  <TextValidator
                  label='lastname'
                  onChange={this.handleLastnameChange}
                  name="username"
                  value={lastname}
                  validators={['required']}
                  errorMessages={['this field is required']} />

                  <br></br>

                  <TextValidator
                  label='mobilenumber'
                  onChange={this.handleMobilenumberChange}
                  name="username"
                  value={mobilenumber}
                  validators={['required']}
                  errorMessages={['this field is required']} />

                  <br></br>

                  <TextValidator
                  label='UserName'
                  onChange={this.handleUnameChange}
                  name="username"
                  value={username}
                  validators={['required','isName']}
                  errorMessages={['this field is required','enter a valid username']} />

                  <br></br>
                  </Card>

                  <Card style={style.card} elevation={0}>

                  <TextValidator
                  label='Email'
                  onChange={this.handleEmailChange}
                  name="email"
                  value={email}
                  validators={['required', 'isEmail']}
                  errorMessages={['this field is required', 'email is not valid']}/>
                  <br/>

                  {/* <TextValidator
                  label='Password'
                  type="password"
                  onChange={this.handlePasswordchange}
                  name="password"
                  value={password}
                  validators={['required','isPassword']}
                  errorMessages={['this field is required','enter a valid password']}/>
                  <br/>
                  
                  <TextValidator
                  label='Cofirm Password'
                  type="password"
                  onChange={this.handleconfirmPasswordchange}
                  name="password"
                  value={confirmpassword}
                  validators={['required','isConfirmpw']}
                  errorMessages={['this field is required','your password is not matching']}/> */}
                  <br/>
                  <br/>

                  </Card>
                </Card>
                <br/>
                <br/>
                  
                <Button type="submit" variant="contained" style={{backgroundColor:"lightgreen",color:"black"}} onClick={this.handleSubmit}>
                    Update
                </Button>
                <Button variant="contained" style={{backgroundColor:"red",color:"black",marginLeft:30}}>
                    Cancel
                </Button>
                  <br/>

                    {
                      this.state.message && (
                      <div>
                        <Typography color={this.state.successful ? 'primary' : 'error'} variant="overline" display="block" gutterBottom>
                            <strong>{this.state.message}</strong>
                        </Typography>
                      </div>
                    )
                    }
                    <br/>
              </ValidatorForm>
              </Card>
                {/* </Card> */}
            </div>
        )
    }
}