import React, { Component } from 'react'

export default class ImageUpload extends Component{
    constructor(){
        super();
    }

    render(){
        return(
            <div>
                <input type="file"/>
            </div>
        );

    }
}