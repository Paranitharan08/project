import React, { Component } from 'react'
import { Card, CardContent, TextField, FormControl, Grid, Button, Paper, Typography } from '@material-ui/core'
import bg from './images/Loginpic.jpg';
import {ValidatorForm} from 'react-form-validator-core';

const style = {
    card : {
        width:300,
        height:300,
        backgroundColor:"transparent",
        marginTop:"10%",
        marginLeft:"50%",
        borderRadius:30, 
        color:"black"
    }
}


export default class Login extends Component{
    constructor(){
        super();

        this.state={
          loginusername:"",
          loginpassword:"",
        };
    }

    handleUnameChange= (e) => {
      this.setState({
        loginusername: e.target.value
      });
      console.log(this.state.loginusername);
  }
    handlePasswordchange = (e) => {
      this.setState({
        loginpassword: e.target.value
      });
      console.log(this.state.loginpassword);
  }

  handleSubmit= (e) => {
    e.preventDefault();
    console.log(this.state.loginusername);
    console.log(this.state.loginpassword);
    if (this.state.loginusername && this.state.loginpassword) {
      this.props.history.push("/sos");
      window.location.reload();
      } else {
        this.setState({
          // successful: false,
          message: "username/password is empty"
        })
      }
      

      // AuthService.login(this.state.username, this.state.password)
      //   .then(() => {
      //     this.props.history.push("/profile");
      //     window.location.reload();
      //   },
      //   error => {
      //     const resMessage = 
      //     (error.response && 
      //       error.response.data &&
      //       error.response.data.message) ||
      //     error.message ||
      //     error.toString();

      //     this.setState({
      //       loading: false,
      //       message: resMessage
      //     });

}

    render(){
      const {loginusername, loginpassword} = this.state;
        return(
          <div style={{backgroundImage:`url(${bg})`, backgroundRepeat:"no-repeat", backgroundSize:"cover", height:"100vh",width:"100vw"}}>
            <div>
            <Card>

            </Card>
            <Card style={style.card} elevation={0} variant="outlined">
              <CardContent>
              <form
              onSubmit={this.handleSubmit}
              >
                <TextField 
                variant="standard" 
                label="Username" 
                value={loginusername}
                onChange={this.handleUnameChange}
                style={{marginTop:40,borderRadius:10}}
                validators={['required']}
                />

                <TextField 
                variant="standard" 
                label="Password" 
                value={loginpassword}
                style={{marginTop:10,borderRadius:10}}
                onChange={this.handlePasswordchange}
                type="password"
                />

                <Button
                variant="contained"
                name="Login"
                style={{marginTop:10,color:"black",backgroundColor:"sienna",marginLeft:80,color:"white"}}
                type="submit"
                >Login</Button>

{
                      this.state.message && (
                      <div>
                        <Typography color={this.state.successful ? 'primary' : 'error'} variant="overline" display="block" gutterBottom>
                            <strong>{this.state.message}</strong>
                        </Typography>
                      </div>
                    )
                    }
              </form>
              <br/>
              <boom>
                Don't have an account?. Signup <a href="#">here</a>
              </boom>
              </CardContent>
              </Card>
            </div>
            
          </div>
        )
    }
}