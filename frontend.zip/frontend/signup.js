import React, { Component } from 'react'
import { Card, CardContent, TextField, FormControl, Grid, Button, Paper } from '@material-ui/core'
import sign from './images/signuppic.jpg'
// import background2 from './home.css';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';

const style = {
    card : {
        width:300,
        height:450,
        backgroundColor:"transparent",
        marginTop:"5%",
        marginLeft:"10%",
        color:"white",
        borderRadius:30, 
    }
}

export default class Signup extends Component{
    constructor(){
        super();
    }
    render(){
        return(
          <div style={{backgroundImage:`url(${sign})`,backgroundRepeat:"no-repeat", backgroundSize:"cover", height:"100vh",width:"100vw"}}>
            {/* backgroundImage:`url(${sign})`  */}
            <div>
            <Card>

            </Card>
            <Card style={style.card}>
              <CardContent>
              <ValidatorForm>
                <TextValidator 
                variant="standard" 
                label="Username" 
                style={{marginTop:40,borderRadius:10, color:'red'}}
                />
                
                <TextValidator 
                variant="standard" 
                label="Email" 
                validators={['required','isEmail']}
                errorMessages={['Email is required','Please enter a valid Email']}
                style={{marginTop:10,borderRadius:10}}
                />

                <TextValidator 
                variant="standard" 
                label="Mobile Number" 
                style={{marginTop:10,borderRadius:10}}
                />

                <TextValidator 
                variant="standard" 
                label="Password"
                type="password" 
                style={{marginTop:10,borderRadius:10}}
                />

                <TextValidator 
                variant="standard" 
                label="Confirm Password" 
                style={{marginTop:10,borderRadius:10}}
                type="password"
                />

                <Button
                variant="outlined"
                name="Login"
                style={{marginTop:10,color:"black",backgroundColor:"white",marginLeft:80,borderRadius:20}}
                >Signup</Button>
              <br/>
              <boom>
                Already have an account?. Login <a href="#" style={{color:"red"}}>here</a>
              </boom>
              </ValidatorForm>
              </CardContent>
            </Card>
            </div>
        //   </div>
        )
    }
}