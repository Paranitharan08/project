export default function authHeader() {
    const user = JSON.parse(localStorage.getItem('users'));

if (user && user.basicToken) {
    return {Authorization: 'Basic'+ user.basicToken};
} else{
    return {};
 }
}