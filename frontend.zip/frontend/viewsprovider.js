import React, { Component } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';
import { Button, TableFooter, TablePagination } from '@material-ui/core';

import EditIcon from '@material-ui/icons/Edit';
import PropTypes from 'prop-types';
import { useTheme } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Apiservice from '../Services/Apiservice';


const useStyles1 = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};




export default class ViewsProvider extends Component {
  constructor(){
    super();
    this.state={
     servicestations:[],
     page:0,
     rowsPerPage:5,
     count:0
    
    }

  }

  componentDidMount(){
    this.getallservicestation();
  }

  
  


  handleChangePage = (event,newPage) => {
    this.setState({
      page:newPage
    });

    Apiservice.getallservicestation(newPage,5)
  .then((response) => {
    console.log(response.data.data);
    this.setState({
        servicestations:response.data.data,
      count:response.data.Totalnoofelements      
    })
    console.log(this.state.users);
  })
  };

  getallservicestation = () => {
    Apiservice.getAllUserInPage(this.state.page,5)
    .then((response) => {
      this.setState ({
        servicestations:response.data.data,
        count:response.data.data.Totalnoofelements
      })
    })
  }
  deleteServicestation = (ServicestationsId)=>{
    Apiservice.deleteServicestation(ServicestationsId)
    .then(res => {
      this.setState({message:'User deleted successfully,'});
      this.setState({servicestations:this.state.servicestations.filter(servicestations => servicestations!==ServicestationsId)});
    });
  }


  handleChangeRowsPerPage = (event) => {
    this.setState({
      page:0,
      rowsPerPage:event.target.value
    })
  };
  
  
render(){
  const users = this.state.servicestations;
  return (
      <Paper>
    <TableContainer style={{backgroundColor:"lightgray",marginTop:80, border:"2px solid black"}}  component={Paper}>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow style={{backgroundColor:"black"}}>
          <TableCell style={{color:"gold"}}></TableCell>
          <TableCell style={{color:"gold"}}></TableCell>
            <TableCell style={{color:"gold"}}><b>companyName</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>phoneNumber</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>emailAddress</b></TableCell>
            <TableCell style={{color:"gold"}}><b>address</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>workDistance</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>latitude</b></TableCell>
            <TableCell style={{color:"gold"}}><b>longtitude</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>opentime</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>finishtime</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>describtion</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>serviceType</b></TableCell>
            <TableCell style={{color:"gold"}} align="right"><b>vehicleTypes</b></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map(row =>(
            
            <TableRow key={row.id}>
              <TableCell onClick={()=>this.deleteServicestation(row.id)}><Button><DeleteRoundedIcon/></Button></TableCell>
              <TableCell><Button href={"/updateservicestation/"+row.id} ><EditIcon/></Button></TableCell>
              <TableCell component="th" scope="row">{row.companyName}</TableCell>
              <TableCell align="right">{row.phoneNumber}</TableCell>
              <TableCell align="right">{row.emailAddress}</TableCell>
              <TableCell align="right">{row.address}</TableCell>
              <TableCell align="right">{row.workDistance}</TableCell>
              <TableCell align="right">{row.latitude}</TableCell>
              <TableCell align="right">{row.longtitude}</TableCell>
              <TableCell align="right">{row.opentime}</TableCell>
              <TableCell align="right">{row.finishtime}</TableCell>
              <TableCell align="right">{row.describtion}</TableCell>
              <TableCell align="right">{row.serviceType}</TableCell>
              <TableCell align="right">{row.vehicleTypes}</TableCell>
            </TableRow>
            ))}
{/* companyName:this.state.companyName,
  phoneNumber:this.state.phoneNumber,
  emailAddress:this.state.emailAddress,
  address:this.state.address,
  workDistance:this.state.workDistance,
  latitude:this.state.latitude,
  longtitude:this.state.longtitude,
  opentime:this.state.opentime,
  finishtime:this.state.finishtime,
  description:this.state.description,
  serviceType:this.state.serviceType,
  vehicleTypes:this.state.vehicleTypes, */}
            
          
        </TableBody>
        <TableFooter>
          <TableRow>
            <TablePagination
              count={this.state.count}
              rowsPerPage={this.state.rowsPerPage}
              page={this.state.page}
              SelectProps={{
                inputProps: { 'aria-label': 'rows per page' },
                native: true,
              }}
              onChangePage={this.handleChangePage}
              onChangeRowsPerPage={this.handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
          </TableRow>
        </TableFooter>
      </Table>
    </TableContainer>
    </Paper>
  );
  }
}
