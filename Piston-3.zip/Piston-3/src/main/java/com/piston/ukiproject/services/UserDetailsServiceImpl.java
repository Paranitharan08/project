package com.piston.ukiproject.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.piston.ukiproject.models.User;
import com.piston.ukiproject.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	UserRepository userRepository;
	
	public ResponseEntity< List<User>> getAllUser(){
		try {
			List<User> user = userRepository.findAll();
			if (user.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<> (user,HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<User> getUserById(String id) {
		Optional<User> user =userRepository.findById(id);
		if (user.isPresent()) {
			return new ResponseEntity<>(user.get(),HttpStatus.OK);
		} else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<User> deleteUserById(String id) {
		try {
			userRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
//	public ResponseEntity<User> getCurrentUser(String id){
//		Optional<User> user =userRepository.findById(id);
//		if (user.isPresent()) {
////			System.out.println("udgufgdugyfkjd<gshjkvhsvkjdsggvdskjghfhgsdjka");
//			return new ResponseEntity<>(user.get(),HttpStatus.OK);
//		} else {
//			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
//		}
//	}
	
	public ResponseEntity<User> updateUserById(User user, String id){
//		System.out.println("shgfuhsuagucvghsuaujhdgucgusa");
		Optional<User> oldUser = userRepository.findById(id);
		
		try {
			if (oldUser.isPresent()) {
				User _user = oldUser.get();
				_user.setFirstname(user.getFirstname());
				_user.setLastname(user.getLastname());
//				_user.setUsername(user.getUsername());
				_user.setMobilenumber(user.getMobilenumber());
//				_user.setEmail(user.getEmail());
				_user.setRoles(user.getRoles());
				_user.setImage(user.getImage());
//				_user.setPassword(newUser.getPassword());
				

				return new ResponseEntity<> (userRepository.save(_user),HttpStatus.OK);
			} else {
				return new ResponseEntity<> (HttpStatus.NOT_FOUND);
			}
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	

	
	public ResponseEntity<Map<String, Object>> getAllUserInPage(int pageNo, int pageSize, String sortBy) {
		try {
			Map<String, Object>response=new HashMap<>();
			Sort sort=Sort.by(sortBy);
			Pageable pageable=PageRequest.of(pageNo, pageSize, sort);
			Page<User> page=userRepository.findAll(pageable);
			response.put("data", page.getContent());
			response.put("Total no of pages", page.getTotalPages());
			response.put("Totalnoofelements", page.getTotalElements());
			response.put("Current page no", page.getNumber());
			
			return new ResponseEntity<>(response,HttpStatus.OK);
	    }catch(Exception e) {
	    	return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
	    }
		
	}

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));

		return UserDetailsImpl.build(user);
	}

}
