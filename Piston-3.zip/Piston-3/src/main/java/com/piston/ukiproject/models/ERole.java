package com.piston.ukiproject.models;

public enum ERole {
  ROLE_CUSTOMER,
  ROLE_SPROVIDER,
  ROLE_ADMIN
}
