package com.piston.ukiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Piston3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
