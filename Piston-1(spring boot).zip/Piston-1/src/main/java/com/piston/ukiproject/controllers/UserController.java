package com.piston.ukiproject.controllers;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.piston.ukiproject.models.User;
import com.piston.ukiproject.services.UserDetailsServiceImpl;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;
	
	@GetMapping
	public ResponseEntity< List<User>> getAllUser(){
		return userDetailsServiceImpl.getAllUser();
	}
	
	@GetMapping("/{id}")
	public  ResponseEntity <User> getUserById(@PathVariable String id) {
		return userDetailsServiceImpl.getUserById(id);
		}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<User>  deleteUser(@PathVariable String id) {
	return userDetailsServiceImpl.deleteUserById(id);
	}
	
	@GetMapping("/page")
	   public ResponseEntity<Map<String, Object>> getAllUserInPage(
	    @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
	    @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
	    @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
	return userDetailsServiceImpl.getAllUserInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping("/all")
	public String allAccess() {
		return "public content";
	}
	
	@GetMapping("/customer")
	@PreAuthorize("hasRole('CUSTOMER') or hasRole('SPROVIDER') or hasRole('ADMIN')")
	public String customerAccess() {
		return "user Content";
	}
	
	@GetMapping("/sprovider")
	@PreAuthorize("hasRole('SPROVIDER')")
	public String sproviderAccess() {
		return "Sprovider board";
	}
	
	@GetMapping("/admin")
	@PreAuthorize("hasRole('ADMIN')")
	public String adminAccess() {
		return "admin board";
	}
	
	
	
	}



