package com.piston.ukiproject.models.response;

import java.util.List;

public class BasicAuthResponse {
	private String token;
	private String type = "Basic";
	private String id;
	private String username;
	private String email;
	private String firstname;
	private String lastname;
	private String mobilenumber;
	private List<String> roles;

	public BasicAuthResponse(String basicToken, String id, String username, String email, List<String> roles, String firstname, String lastname, String mobilenumber) {
		this.token = basicToken;
		this.id = id;
		this.username = username;
		this.email = email;
		this.roles = roles;
		this.firstname = firstname;
		this.lastname = lastname;
		this.mobilenumber = mobilenumber;
	}

	public String getBasicToken() {
		return token;
	}

	public void setBasicToken(String basicToken) {
		this.token = basicToken;
	}

	public String getTokenType() {
		return type;
	}

	public void setTokenType(String tokenType) {
		this.type = tokenType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getRoles() {
		return roles;
	}

}
