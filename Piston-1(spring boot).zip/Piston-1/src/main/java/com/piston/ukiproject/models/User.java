package com.piston.ukiproject.models;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;

	
@Document(collection = "users")
public class User{
	@Id
	private String id;
	
	@NotBlank
	@Size(min = 3, max = 30)
	private String firstname;
	
	@NotBlank
	@Size(min = 3, max = 30)
	private String lastname;
	
	@NotBlank
	@Size(min = 9, max = 15)
	private String mobilenumber;

	@NotBlank
	@Size(min =3, max = 30 )
	private String username;
	
	@NotBlank
	@Size(max = 50)
	@Email
	private String email;
	
	@NotBlank
	@Size(min = 8, max = 30)
	private String password;
	
	@DBRef
	private Set<Role> roles = new HashSet<>();
	
//	public User() {
//	}
	
	

	public User(@NotBlank @Size(min = 3, max = 30) String username, @NotBlank @Size(max = 50) @Email String email, @NotBlank @Size(min = 3, max = 30) String firstname,
		@NotBlank @Size(min = 3, max = 30) String lastname, @NotBlank @Size(min = 9, max = 15) String mobilenumber ,@NotBlank @Size(min = 8, max = 30) String password) {
		super();
		this.username = username;
		this.email = email;
		this.password = password;
		this.firstname  = firstname;
		this.lastname = lastname;
		this.mobilenumber = mobilenumber;
	}
	
	


	public User() {
		super();
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getFirstname() {
		return firstname;
	}
	
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public String getLastname() {
		return lastname;
	}
	
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public String getMobilenumber() {
		return mobilenumber;
	}
	
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	
	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

}




