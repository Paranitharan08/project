package com.piston.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


//import javax.validation.executable.ValidateOnExecution;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Example;
//import org.springframework.data.domain.ExampleMatcher;
//import org.springframework.data.domain.ExampleMatcher.GenericPropertyMatcher;
//import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.piston.exception.RecordNotFoundException;

import com.piston.model.Servicestation;
import com.piston.repository.ServicestationCustom;
import com.piston.repository.ServicestationRepository;





@Service
public class Servicestationservice {
	 @Autowired
		private ServicestationCustom servicestationCustom;

	@Autowired
	ServicestationRepository servicestationRepository;

	public ResponseEntity<List<Servicestation>> getAllServicestations() {
		List<Servicestation> servicestations = new ArrayList<Servicestation>();
		servicestationRepository.findAll().forEach(servicestations::add);
	
	    if (servicestations.isEmpty()) {
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	    return new ResponseEntity<>(servicestations, HttpStatus.OK);
	}
	
	








	public ResponseEntity<Servicestation> createServicestation( Servicestation servicestation) {
		

		try {
			Date date= new Date();
			servicestation.setDate(date.getHours()+":"+date.getMinutes());
			Servicestation servicestations =servicestationRepository.insert(servicestation);
			
			return new ResponseEntity<>(servicestations,HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}







	public ResponseEntity<HttpStatus> deleteServicestationbyId(String id) throws RecordNotFoundException
	{
		Optional<Servicestation> deleteservicestation = servicestationRepository.findById(id);
			if(deleteservicestation.isPresent()) {
				servicestationRepository.delete(deleteservicestation.get());
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				throw new RecordNotFoundException("Not Deleted by this"+id);
			
			}
			
		}



	public ResponseEntity<HttpStatus> deleteAllservicestation() {
		try {
			List<Servicestation> station=servicestationRepository.findAll();
			
			if (station.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			} else {
				servicestationRepository.deleteAll(station);
			}
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		}






	public ResponseEntity<Map<String, Object>> getAllServiceStationsInPage(int pageNo, int pageSize, String sortBy) {
		 try {
	   		 Map<String, Object> response = new HashMap<>();
	   	 	Sort sort = Sort.by(sortBy);
	   		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
	   	 	Page<Servicestation> page = servicestationRepository.findAll(pageable);
	   	 	response.put("data", page.getContent());
	   	 	response.put("Total_no_of_pages", page.getTotalPages());
	   	 	response.put("Total_no_of_elements", page.getTotalElements());
	   	 	response.put("Current_page_no", page.getNumber());
	   		 
	   	 	return new ResponseEntity<>(response, HttpStatus.OK);
	   	 } catch (Exception e) {
	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	   	 }

		
	}










	public ResponseEntity<Servicestation> updateServicestation(String id, Servicestation servicestation) {
		 Optional<Servicestation> servicestationData = servicestationRepository.findById(id);

	   	 if (servicestationData.isPresent()) {
	   		 Servicestation _servicestation = servicestationData.get();
	   		_servicestation.setAddress(servicestation.getAddress());
	   		_servicestation.setCompanyName(servicestation.getCompanyName());
	   	 	_servicestation.setDescription(servicestation.getDescription());
	   	 	_servicestation.setEmailAddress(servicestation.getEmailAddress());
	   	 	_servicestation.setFinishtime(servicestation.getFinishtime());
	   	 	_servicestation.setLatitude(servicestation.getLatitude());
	   	 	_servicestation.setLongtitude(servicestation.getLongtitude());
	   	 	_servicestation.setOpentime(servicestation.getOpentime());
	   	 _servicestation.setPhoneNumber(servicestation.getPhoneNumber());
	   	 	_servicestation.setWorkDistance(servicestation.getWorkDistance());
	   	 	
//	   	 	_servicestation.setVehicleTypes(servicestation.getVehicleTypes());
//	   	 	_servicestation.setServiceType(servicestation.getServiceType());
	   	 	
	  
	   	 	return new ResponseEntity<>(servicestationRepository.save(_servicestation), HttpStatus.OK);
	   	 } else {
	   	 	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	   	 }

	}












	public ResponseEntity<List<Servicestation>> getQuickByFilter(String serviceType, String vehicleType,Double longtitude,Double latitude) {
System.out.println(vehicleType);
System.out.println("hii");

		try {
			
			SimpleDateFormat parser =new SimpleDateFormat("HH:mm");
			List<Servicestation> servicefilter = new ArrayList<Servicestation>();
	   	 	List<Servicestation> Servicestations= servicestationRepository.findAll();
	   	 System.out.println(Servicestations);
	   	 	for (Servicestation servicestation : Servicestations) {
	   	   	 

				String[] dbservicetypes = servicestation.getServiceType();
				System.out.println("111111"+Arrays.toString(dbservicetypes));
				String[] dbvehicletypes = servicestation.getVehicleTypes();
				dbservicetypes = Arrays.stream(dbservicetypes).
						filter(s->(s != null && s.length()>0)).
						toArray(String[] :: new);
				System.out.println("111111"+Arrays.toString(dbservicetypes));

				dbvehicletypes = Arrays.stream(dbvehicletypes).
						filter(s->(s != null && s.length()>0)).
						toArray(String[] :: new);
				
				Date openTime=parser.parse(servicestation.getOpentime());			
				Date finshTime=parser.parse(servicestation.getFinishtime());
			

		        List<String> list = Arrays.asList(dbservicetypes);
				System.out.println("111111");
				for(int i=0;i<list.size();i++){
				    System.out.println(list.get(i).toString());
				} 

		        List<String> list1 = Arrays.asList(dbvehicletypes);

		        Date date=new Date();
		     Date currentTime= parser.parse(date.getHours()+":"+date.getMinutes());
		        Double calculatedDistance = distance(servicestation.getLatitude(),servicestation.getLongtitude(),latitude,longtitude);
		       System.out.println(calculatedDistance);

		        if( list1 != null && list1.contains(vehicleType) && list != null && list.contains(serviceType) && currentTime.after(openTime) && currentTime.before(finshTime) && (calculatedDistance<=servicestation.getWorkDistance())){
		        	
		            System.out.println("Ok");
		            servicefilter.add(servicestation);
		        }
		        System.out.println("Not OK");
	   	 	}

	   	 	if (servicefilter.isEmpty()) {
	   	 		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	   	 	}

	   	 	return new ResponseEntity<>(servicefilter, HttpStatus.OK);
	   	 } catch (Exception e) {
	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	   	 }
	}


	private static double distance(double Companylatitude, double Companylongitude, double Customerlatitude, double Customerlongitude) {
		String unit="K";
	    if ((Companylatitude == Customerlatitude) && (Companylongitude == Customerlongitude)) {
	        return 0;
	    } else {


	        double theta = Companylongitude - Customerlongitude;
	        double dist = Math.sin(Math.toRadians(Companylatitude)) * Math.sin(Math.toRadians(Customerlatitude)) + Math.cos(Math.toRadians(Companylatitude)) * Math.cos(Math.toRadians(Customerlatitude)) * Math.cos(Math.toRadians(theta));
	        dist = Math.acos(dist);
	        dist = Math.toDegrees(dist);
	        dist = dist * 60 * 1.1515;
	        if (unit.equals("K")) {
	            dist = dist * 1.609344;

	            if (dist <= 1000) {
	                return (dist);
	            }

	        }
	        return 0;

	    }
	}










	public ResponseEntity<Servicestation> getservicestationByid(String id) {
		Optional<Servicestation> servicestaions=servicestationRepository.findById(id);
		try {
			if (servicestaions.isPresent()) {
				return new ResponseEntity<>(servicestaions.get(),HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
}










	
