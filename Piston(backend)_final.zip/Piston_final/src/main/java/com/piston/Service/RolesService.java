package com.piston.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.piston.model.Role;
import com.piston.repository.RoleRepository;

@Service
public class RolesService {
	
	@Autowired
	RoleRepository roleRepository;
	
	public ResponseEntity< List<Role>> getAllRole(){
		try {
			List<Role> role = roleRepository.findAll();
			if (role.isEmpty()) {
				System.out.print("sasi");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			System.out.print("sasi2");
			return new ResponseEntity<> (role,HttpStatus.OK);
		}
		catch (Exception e) {
			System.out.print("sasi3");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
