package com.piston.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.piston.model.Feedback;
import com.piston.model.contactUs;
import com.piston.repository.contactUsRepository;


@Service
public class contactUsService {
	
@Autowired
contactUsRepository contactusRepository;
	
public ResponseEntity<List<contactUs>> getAllMessages() {
	try {
		List<contactUs> messag=new ArrayList<contactUs>();
		contactusRepository.findAll().forEach(messag::add);
		if (messag.isEmpty()) {
			 return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(messag,HttpStatus.OK);
	} catch (Exception e) {
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

public ResponseEntity<contactUs> createMessages(contactUs messages) {
	try {
		messages.setDate(new Date());
		contactUs messagesNew=contactusRepository.save(messages);

		return new ResponseEntity<>(messagesNew, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

	}
}

public ResponseEntity<HttpStatus> deleteMessageById(String id) {
	try {
		Optional<contactUs> message=contactusRepository.findById(id);
		
		if (message.isPresent()) {
			contactusRepository.delete(message.get());
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	} catch (Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

public ResponseEntity<Map<String, Object>> getAllmessagesInPage(int pageNo, int pageSize, String sortBy) {
	 try {
           Map<String, Object> response = new HashMap<>();
           Sort sort = Sort.by(sortBy);
           Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
           Page<contactUs> page = contactusRepository.findAll(pageable);
           response.put("data", page.getContent());
           response.put("Total_no_of_pages", page.getTotalPages());
           response.put("Total_No_Of_Elements", page.getTotalElements());
           response.put("Current_page_no", page.getNumber());
           
           return new ResponseEntity<>(response, HttpStatus.OK);
       } catch (Exception e) {
           return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
       }

}

}
