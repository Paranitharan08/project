package com.piston.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.piston.model.ERole;
import com.piston.model.Role;
import com.piston.model.User;
import com.piston.repository.RoleRepository;
import com.piston.Service.UserDetailsServiceImpl;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestController {
	
	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	RoleRepository roleRepository;
	

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping
	public ResponseEntity< List<User>> getAllUser(){
		return userDetailsServiceImpl.getAllUser();
	}
	
	@GetMapping("/{id}")
	public  ResponseEntity <User> getUserById(@PathVariable String id) {
		return userDetailsServiceImpl.getUserById(id);
	}
	
	
//	@GetMapping("/{id}")
//	public  ResponseEntity <User> getCurrentUser(@PathVariable String id) {
//		return userDetailsServiceImpl.getCurrentUser(id);
//	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<User>  deleteUser(@PathVariable String id) {
	return userDetailsServiceImpl.deleteUserById(id);
	}
	
	@PutMapping("updateuser/{id}")
	public ResponseEntity <User> updateTutorial(@RequestBody User user, @PathVariable String id){
		
		System.out.println();
		
		Set<String> strRoles = user.getUpdateroles();
		Set<Role> roles = new HashSet<>();

		strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);

					break;
				case "sprovider":
					Role sproviderRole = roleRepository.findByName(ERole.ROLE_SPROVIDER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(sproviderRole);

					break;
				default:
					Role customerRole = roleRepository.findByName(ERole.ROLE_CUSTOMER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(customerRole);
				}
			
		});

		user.setRoles(roles);
		
		return userDetailsServiceImpl.updateUserById(user, id);
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/page")
	   public ResponseEntity<Map<String, Object>> getAllUserInPage(
	    @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
	    @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
	    @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
	return userDetailsServiceImpl.getAllUserInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping("/all")
	public String allAccess() {
		return "Public Content.";
	}
	
	@GetMapping("/user")
	@PreAuthorize("hasRole('customer') or hasRole('sprovider') or hasRole('ROLE_ADMIN')")
	public String userAccess() {
		return "customer Content.";
	}

	@GetMapping("/mod")
	@PreAuthorize("hasRole('sprovider')")
	public String moderatorAccess() {
		return "sprovider Board.";
	}

//	@GetMapping("/ROLE_ADMIN")
//	@PreAuthorize("hasRole('ROLE_ADMIN')")
//	public String adminAccess() {
//		return "Admin Board.";
//	}
}
