package com.piston.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;


import javax.validation.Valid;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.piston.Service.Servicestationservice;
import com.piston.exception.RecordNotFoundException;

import com.piston.model.Servicestation;



@CrossOrigin("*")
@RestController
@RequestMapping("/api/test/piston/servicestations")
public class ServicestationController {
	
	@Autowired
	private Servicestationservice servicestationservice;
	
	
	 @GetMapping
	    public ResponseEntity<List<Servicestation>> getAllServicestations() {
	        return servicestationservice.getAllServicestations();
	    }
	 

	  @DeleteMapping("/{id}")  
	  public ResponseEntity<HttpStatus> deleteServicestationbyId(@PathVariable String id) throws RecordNotFoundException {
	        return servicestationservice.deleteServicestationbyId(id);
	    }
	  
   @PostMapping
      public ResponseEntity<Servicestation> createServicestation(@Valid  @RequestBody Servicestation servicestation) {
    return servicestationservice.createServicestation(servicestation);
		        }
		        
   @DeleteMapping
   	  public void deleteAllServicestation() throws RecordNotFoundException {
	         servicestationservice.deleteAllservicestation();
	    }
   @GetMapping("/page")
	public ResponseEntity<Map<String, Object>> getAllEmployeesInPage(
  		 @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
  		 @RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
  		 @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
  	 return servicestationservice.getAllServiceStationsInPage(pageNo, pageSize, sortBy);
   }


   @PutMapping("/{id}")
   public ResponseEntity<Servicestation> updateServicestation(@PathVariable String id, @RequestBody Servicestation servicestation) {
       return servicestationservice.updateServicestation(id, servicestation);
   }


   @GetMapping(params= {"serviceType","vehicleType","longtitude","latitude"})

   public ResponseEntity<List<Servicestation>> getQuickByFilter(@RequestParam String serviceType,@RequestParam String vehicleType,@RequestParam Double longtitude ,@RequestParam Double latitude) {

	  return servicestationservice.getQuickByFilter(serviceType,vehicleType,longtitude,latitude);
	    }
   
   @GetMapping("/{id}")
   public ResponseEntity<Servicestation> getservicestationByid(@PathVariable String id){
	   return servicestationservice.getservicestationByid(id);
   }
      }







