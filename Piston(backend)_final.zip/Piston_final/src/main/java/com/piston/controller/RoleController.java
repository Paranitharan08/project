package com.piston.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.piston.model.Role;
//import com.piston.ukiproject.models.User;
import com.piston.Service.RolesService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/test")
public class RoleController {
	
	@Autowired
	RolesService rolesService;

	@GetMapping("/roles")
	public ResponseEntity< List<Role>> getAllRole(){
//		System.out.print("okeyyyy");
		return rolesService.getAllRole();
	}
}
