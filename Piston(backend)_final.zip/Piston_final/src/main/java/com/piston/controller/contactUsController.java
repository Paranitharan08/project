package com.piston.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.piston.model.contactUs;
import com.piston.Service.contactUsService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/test/ContactUs")
public class contactUsController {
	@Autowired
	contactUsService contactusservice;
	
	
	
	@GetMapping
	public ResponseEntity <List<contactUs>> getAllMessages(){
		return contactusservice.getAllMessages();
		
	}
	@PostMapping
	public ResponseEntity<contactUs> createMessages(@RequestBody contactUs messages ) {
		return contactusservice.createMessages(messages);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteMessageById(@PathVariable String id) {
		return contactusservice.deleteMessageById(id);
	}
	
	
	 @GetMapping("/page")
	    public ResponseEntity<Map<String, Object>> getAllmessagesInPage(
	            @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
	            @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
	            @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
	        return contactusservice.getAllmessagesInPage(pageNo, pageSize, sortBy);
	    }

}
