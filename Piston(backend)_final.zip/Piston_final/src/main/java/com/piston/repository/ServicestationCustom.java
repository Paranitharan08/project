package com.piston.repository;

import java.util.List;

import com.piston.model.Servicestation;

public interface ServicestationCustom {
	public List<Servicestation> getMinWorkId();

	
}
