package com.piston.repository;

import org.springframework.stereotype.Repository;

import com.piston.model.Servicestation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Repository
public class ServicestationCustomimplement implements ServicestationCustom{

	@Autowired
    MongoTemplate mongoTemplate;

 
    public List<Servicestation> getMinWorkId() {
        Query query = new Query();
        query.addCriteria(Criteria.where("phoneNumber").in(777));
      
        return mongoTemplate.find(query, Servicestation.class);
    
      
    }

}
