package com.piston.repository;



import java.util.List;
import java.util.Optional;


import org.springframework.data.mongodb.repository.MongoRepository;


import org.springframework.stereotype.Repository;

import com.piston.model.Quickrepair;

@Repository
public interface QuickrepairRepository extends MongoRepository<Quickrepair,String> {

	List<Quickrepair> findQuickRepairByuserid(String userid);

	
	
}
