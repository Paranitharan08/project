package com.piston.model;

import java.util.Arrays;
import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Quickrepair")
public class Quickrepair {

	@Id
	private String id;
	private String userid;
	private Date date;
	private String serviceStationName;
	private String serviceType;
	private String vehicleType;
	private String phoneNumber;
	public Quickrepair(String id, String userid, Date date, String serviceStationName, String serviceType,
			String vehicleType, String phoneNumber) {
		super();
		this.id = id;
		this.userid = userid;
		this.date = date;
		this.serviceStationName = serviceStationName;
		this.serviceType = serviceType;
		this.vehicleType = vehicleType;
		this.phoneNumber = phoneNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getServiceStationName() {
		return serviceStationName;
	}
	public void setServiceStationName(String serviceStationName) {
		this.serviceStationName = serviceStationName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "Quickrepair [id=" + id + ", userid=" + userid + ", date=" + date + ", serviceStationName="
				+ serviceStationName + ", serviceType=" + serviceType + ", vehicleType=" + vehicleType
				+ ", phoneNumber=" + phoneNumber + "]";
	}
//	@Override
	
	
//	public String toString() {
//		return "Quickrepair [id=" + id + ", userid=" + userid + ", date=" + date + ", serviceStationName="
//				+ serviceStationName + ", serviceType=" + serviceType + ", vehicleType=" + vehicleType + "]";
//	}
	
	
	


	
}
