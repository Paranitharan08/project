package com.piston.model;

public enum ERole {
  ROLE_CUSTOMER,
  ROLE_SPROVIDER,
  ROLE_ADMIN
}
