package com.piston.model;

import java.util.Date;

import org.springframework.data.annotation.Id;

public class contactUs {
	@Id
	private String id;
	private String name;
	private String email;
	private String messages;
	private Date date;
	
	public contactUs(String id, String name, String email, String messages, Date date) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.messages = messages;
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessages() {
		return messages;
	}

	public void setMessages(String messages) {
		this.messages = messages;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "contactUs [id=" + id + ", name=" + name + ", email=" + email + ", messages=" + messages + ", date="
				+ date + "]";
	}
	
	
}